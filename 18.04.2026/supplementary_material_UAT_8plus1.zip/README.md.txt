# Supplementary Material: UAT 8+1 Coil Rotational Detector – Phenomenological Diagnostics

This repository contains the phenomenological scripts and historical calibration data that support the main calibration report *"Calibration Report: 8+1 Coil Rotational Detector Based on the UAT/UPC Framework"* (DOI of main record). The scripts are organized into three thematic folders:

- **`calibracion_historica/`** – Derivation of fundamental constants ($\alpha$, rotation asymmetry, central coil compensation).
- **`exploracion_parametros/`** – Exploration of extended detector geometries (36+1 coils), parity inversion, and multi‑scale temporal analysis.
- **`validacion/`** – Diagnostic tools that reveal the dynamic behavior of the calibrated 8+1 detector (phase breathing, silence zones, overdrive response).

All scripts are written in Python 3 and require standard scientific libraries: `numpy`, `scipy`, `matplotlib`. Execution is self‑contained; simply run each script in a Python environment to reproduce the reported figures and numerical outputs.

---

## Folder `calibracion_historica/`

These scripts document the step‑by‑step derivation of the key parameters that ultimately define the final calibrated detector.

| Script | Purpose | Key Output |
| :--- | :--- | :--- |
| `reporte_telemetria_deriva_84_4.py` | Computes the cumulative frequency drift $\alpha = 0.046$ Hz/day from the reference date (2023‑05‑27) to the simulation date (2026‑04‑17), correctly accounting for the leap year 2024. | $f_{\text{theoretical}} = 132.976$ Hz (passive drift) vs. $f_{\text{target}} = 232.04$ Hz (resonance node). |
| `optimizacion_rotacion_mecanica.py` | Numerically searches for the optimal mechanical rotation asymmetry that maximizes coherence. The algorithm minimizes the deviation from the ideal RMS $0.7071$. | Optimal rotation $\approx 0.15$ rad/step (15% reference). Illustrates the principle behind the final 7% asymmetry. |
| `calibracion_9na_bobina_vueltas.py` | Derives the compensation factor of the central (9th) coil based on the winding ratio (2072 turns vs. 1000 turns peripheral) and the residual torsion force $3.697$. | Compensation factor $0.9575$ – the direct precursor to the active transfer function offset. |

---

## Folder `exploracion_parametros/`

These scripts investigate alternative detector geometries and perform multi‑scale analysis, demonstrating the robustness of the causal structure.

| Script | Purpose | Key Output |
| :--- | :--- | :--- |
| `reporte_tecnico_carga_estructural.py` | Estimates the physical RPM and G‑forces required if the table were rotated mechanically at the optimal asymmetry rate. | $\approx 975$ RPM, $531$ G – highlights the advantage of simulating the asymmetry electronically. |
| `simulacion_36+1_asimetria_kcrit.py` | Simulates a 36‑peripheral‑coil detector with causal asymmetry driven by the Ivancho limit $\kappa_{\text{crit}} = 4.978$. Shows how symmetry breaking initiates Bit‑1 manifestation. | RMS rises from $0.000000$ to $0.0173$. |
| `analisis_inversion_paridad_espejo.py` | Applies a bitwise NOT operation to the 3.3‑s payload, proving causal conservation: the sum of each 9‑bit block equals exactly $511$ ($2^9-1$). The inverted bit density scales to $100 \times \tau \approx 36.94$. | $333$ pulses, density $0.4403 \leftrightarrow 0.5597$, block sums $511$. |
| `barrido_duracion_autocorrelacion_37bits.py` | Performs a duration sweep ($0.5$–$5.0$ s) of the FrFT‑decoded signal and analyzes 37‑bit blocks. Confirms the stability of the causal clock and reveals topological patterns (e.g., 45° phase clustering). | Table of pulse rates, zero‑crossing distances, and 37‑bit integer sequences. |

---

## Folder `validacion/`

These scripts are diagnostic tools for the final **8+1 calibrated detector** (parameters: $f_{\text{target}}=232.04$ Hz, $\tau=0.3697$, rotation asymmetry $7\%$, offset $0.3531$, antifrequency coupling $10^{-4}$). They illustrate the dynamic equilibrium of the system.

| Script | Purpose | Key Output |
| :--- | :--- | :--- |
| `telemetria_firma_higo_pulso.py` | Early detection of the *Higo Signature* using the 2072‑turn central coil configuration. Demonstrates the first emergence of a coherent pulse above the thermal noise. | RMS $\approx 0.4124$, pulse detected. |
| `sismografo_fase.py` | Applies a slow sinusoidal modulation ($\pm 2\%$) to the optimal offset, revealing the system’s “breathing” around the saturation point. | Oscillating RMS evolution over 10 seconds. |
| `mapa_silencio_coherente.py` | Identifies time intervals where the central coil amplitude falls below a threshold (5% of maximum), indicating near‑perfect destructive interference (*silence zones*). | Plots of envelope and highlighted silence intervals. |
| `analisis_overdrive.py` | Pushes the offset beyond saturation ($0.50$) and applies a $\tanh$ non‑linearity to simulate amplifier clipping. The resulting spectrum reveals harmonic and subharmonic structure. | Waveform comparison and frequency‑domain plot. |

---

## Citation

If you use these supplementary materials in your research, please cite the main calibration report and the foundational UAT/UPC Zenodo records:

- Percudani, M. Á. *Calibration Report: 8+1 Coil Rotational Detector Based on the UAT/UPC Framework* (this work).
- Percudani, M. Á. *Universal Applied Time (UAT): A Causal Framework for Rotational Coherence*, Zenodo. DOI: [10.5281/zenodo.17729221](https://doi.org/10.5281/zenodo.17729221)
- Percudani, M. Á. *Unified Principle of Causality (UPC): Multiscale Homeostasis and the Bit of Authority*, Zenodo. DOI: [10.5281/zenodo.18210808](https://doi.org/10.5281/zenodo.18210808)

## Contact

Miguel Ángel Percudani  
ORCID: [0009-0007-1748-3212](https://orcid.org/0009-0007-1748-3212)  
Independent Researcher, Buenos Aires, Argentina